# Xaynie Enhancer Android
WebView wrapper for the live Xaynie Enhancer App.

Open this project in Android Studio and choose Build > Build APK(s). The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.

Live app: https://xaynie-enhancer-app-dpva7g.v2.appdeploy.ai/
